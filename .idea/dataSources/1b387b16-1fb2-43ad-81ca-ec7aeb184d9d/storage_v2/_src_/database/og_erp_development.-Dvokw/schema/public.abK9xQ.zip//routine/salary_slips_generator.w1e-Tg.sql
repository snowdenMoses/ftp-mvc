create procedure salary_slips_generator(IN batch_id integer, IN month integer, IN year integer, IN new_created_at date, IN new_updated_at date)
    language plpgsql
as
$$
begin
    -- subtracting the amount from the sender's account
    INSERT INTO account_salary_slips (hr_user_id, account_batch_id,  salary, basic, medical, housing, transport, other_allowances, monthly_salary, monthly_income_tax, monthly_pension, net_pay, disciplinary_deductions, attendance_deduction, salary_month, year, created_at, updated_at)
    SELECT
        hr.id,
        batch_id,
        COALESCE(aes.net_pay - COALESCE(SUM(hr_deductions.amount), 0), aes.net_pay) AS salary,
        aes.basic,
        aes.medical,
        aes.housing,
        aes.transport,
        aes.other_allowances,
        aes.monthly_salary,
        aes.monthly_income_tax,
        aes.monthly_pension,
        COALESCE((aes.net_pay - SUM(hr_deductions.amount)), aes.net_pay),
        COALESCE(SUM(hr_deductions.amount) FILTER(WHERE hr_deductions.category = 1), 0) AS disciplinary_deductions,
        COALESCE(SUM(hr_deductions.amount) FILTER(WHERE hr_deductions.category = 0), 0) AS attendance_deduction,
        month,
        year,
        new_created_at,
        new_updated_at
    FROM
        hr_users hr
            JOIN hr_employees he ON hr.id = he.hr_user_id
            JOIN hr_personal_details hpd ON hr.id = hpd.hr_user_id
            JOIN account_employee_salaries aes ON he.id = aes.hr_employee_id
            LEFT JOIN hr_deductions ON he.hr_user_id = hr_deductions.hr_user_id
            AND
                                       hr_deductions.status = true
            AND
                                       EXTRACT(Month FROM hr_deductions.created_at ) = month
            AND
                                       EXTRACT(Year FROM hr_deductions.created_at ) = year
    WHERE
            hr.status = 1
    GROUP BY
        hr.email,
        hr.id,
        he.ogid,
        hr.id,
        aes.basic,
        aes.medical,
        aes.housing,
        aes.transport,
        aes.other_allowances,
        aes.monthly_salary,
        aes.monthly_income_tax,
        aes.monthly_pension,
        aes.net_pay;

    commit;
end;$$;

alter procedure salary_slips_generator(integer, integer, integer, date, date) owner to postgres;

