create procedure regenerate_salary_slip(IN month integer, IN year integer, IN new_created_at date, IN new_updated_at date, IN user_id integer)
    language plpgsql
as
$$
begin
    -- subtracting the amount from the sender's account
    UPDATE account_salary_slips SET
                                    salary = update_source_subquery.salary,
                                    basic = update_source_subquery.basic,
                                    medical = update_source_subquery.medical,
                                    housing = update_source_subquery.housing,
                                    transport = update_source_subquery.transport,
                                    other_allowances = update_source_subquery.other_allowances,
                                    monthly_salary = update_source_subquery.monthly_salary,
                                    monthly_income_tax = update_source_subquery.monthly_income_tax,
                                    monthly_pension = update_source_subquery.monthly_pension,
                                    net_pay = update_source_subquery.net_pay,
                                    disciplinary_deductions = update_source_subquery.disciplinary_deductions,
                                    attendance_deduction = update_source_subquery.attendance_deduction
    FROM (
    SELECT
                hr.id,
                 COALESCE(aes.net_pay - COALESCE(SUM(hr_deductions.amount), 0), aes.net_pay) AS salary,
                 aes.basic,
                 aes.medical,
                 aes.housing,
                 aes.transport,
                 aes.other_allowances,
                 aes.monthly_salary,
                 aes.monthly_income_tax,
                 aes.monthly_pension,
                 COALESCE((aes.net_pay - SUM(hr_deductions.amount)), aes.net_pay) as net_pay,
                 COALESCE(SUM(hr_deductions.amount) FILTER(WHERE hr_deductions.category = 1), 0) AS disciplinary_deductions,
                 COALESCE(SUM(hr_deductions.amount) FILTER(WHERE hr_deductions.category = 0), 0) AS attendance_deduction,
                 month,
                 year,
                 new_created_at,
                 new_updated_at
    FROM hr_users hr
                   JOIN hr_employees he ON hr.id = he.hr_user_id
                   JOIN hr_personal_details hpd ON hr.id = hpd.hr_user_id
                   JOIN account_employee_salaries aes ON he.id = aes.hr_employee_id
                   LEFT JOIN hr_deductions ON he.hr_user_id = hr_deductions.hr_user_id
    AND
                 hr_deductions.status = true
    AND
                 EXTRACT(Month FROM hr_deductions.created_at) = month
    AND
                 EXTRACT(Year FROM hr_deductions.created_at) = year
    WHERE hr.status = 1
    AND hr.id = user_id
    GROUP BY
        hr.email,
        hr.id,
        he.ogid,
        hr.id,
        aes.basic,
        aes.medical,
        aes.housing,
        aes.transport,
        aes.other_allowances,
        aes.monthly_salary,
        aes.monthly_income_tax,
        aes.monthly_pension,
        aes.net_pay
    ) AS update_source_subquery

    WHERE hr_user_id = user_id;

    commit;
end;$$;

alter procedure regenerate_salary_slip(integer, integer, date, date, integer) owner to postgres;

